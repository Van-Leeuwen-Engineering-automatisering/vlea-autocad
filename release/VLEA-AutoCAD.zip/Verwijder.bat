@echo off
setlocal
rem Verwijdert "VLEA - kaarten voor AutoCAD" voor deze Windows-gebruiker. AutoCAD moet gesloten zijn.
rem Wat er precies gebeurt, staat bovenin Verwijder.ps1.
if not exist "%~dp0Verwijder.ps1" goto nietuitgepakt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Verwijder.ps1" %*
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%

:nietuitgepakt
echo Verwijder.ps1 staat niet naast dit bestand. Pak de zip eerst helemaal uit.
echo.
pause
exit /b 1
