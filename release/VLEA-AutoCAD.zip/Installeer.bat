@echo off
setlocal
rem Installeert "VLEA - kaarten voor AutoCAD" voor deze Windows-gebruiker (geen beheerdersrechten nodig).
rem AutoCAD moet gesloten zijn. Wat er precies gebeurt, staat bovenin Installeer.ps1.
if not exist "%~dp0Installeer.ps1" goto nietuitgepakt
if not exist "%~dp0VLEA-AutoCAD.bundle\PackageContents.xml" goto nietuitgepakt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installeer.ps1" %*
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%

:nietuitgepakt
echo De installatiebestanden staan niet naast dit bestand.
echo Pak de zip eerst helemaal uit (rechtsklik op de zip, Alles uitpakken)
echo en dubbelklik daarna Installeer.bat in de uitgepakte map.
echo.
pause
exit /b 1
