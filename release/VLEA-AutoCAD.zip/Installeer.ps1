# Installeer.ps1 -- installeert "VLEA - kaarten voor AutoCAD" voor deze Windows-gebruiker.
#
# Start dit via Installeer.bat in de UITGEPAKTE zip. Geen beheerdersrechten nodig.
#
# Wat het script doet:
#   1. stopt als de zip niet is uitgepakt, of als AutoCAD nog draait;
#   2. zoekt AutoCAD 2025 (R25.0), 2026 (R25.1) en 2027 (R26.0) op deze pc; AutoCAD LT kan geen
#      plugins laden;
#   3. kopieert VLEA-AutoCAD.bundle naar %APPDATA%\Autodesk\ApplicationPlugins en haalt de
#      downloadmarkering van Windows eraf (Unblock-File);
#   4. zet in elk AutoCAD-profiel van 2025, 2026 en 2027 precies de map
#      ...\VLEA-AutoCAD.bundle\Contents\<jaar> in TRUSTEDPATHS. Dat is een beveiligingsinstelling
#      van AutoCAD: mappen in die lijst mag AutoCAD zonder vraag laden. Verwijder.ps1 haalt die
#      regel weer weg;
#   5. controleert APPAUTOLOAD (staat die op 0, dan laadt AutoCAD geen enkele plugin).
#
# Proefdraai (schrijft niets, laat alleen zien wat er zou gebeuren):
#   powershell -NoProfile -ExecutionPolicy Bypass -File Installeer.ps1 -Proefdraai
#   (of -WhatIf)
#
# ASCII-only: Windows PowerShell 5.1 leest dit bestand als cp1252.

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$Proefdraai,
    [switch]$Ja
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$proef      = [bool]($Proefdraai -or $WhatIfPreference)
# Vangnet: in een proefdraai wordt elke schrijvende cmdlet sowieso alleen gesimuleerd.
if ($proef) { $WhatIfPreference = $true }
$bundelNaam = "VLEA-AutoCAD.bundle"
$series     = [ordered]@{ "R25.0" = "2025"; "R25.1" = "2026"; "R26.0" = "2027" }
$bron       = Join-Path $PSScriptRoot $bundelNaam
$pluginMap  = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins"
$doel       = Join-Path $pluginMap $bundelNaam

function Meld([string]$t) { Write-Host $t }
function Proef([string]$t) { Write-Host "  PROEF: zou $t" }
function Stop-Installatie([string]$t) {
    Write-Host ""
    Write-Host "GESTOPT: $t"
    exit 1
}
function Normaliseer-Pad([string]$p) { return $p.Trim().TrimEnd('\').ToLowerInvariant() }

Meld "=== VLEA - kaarten voor AutoCAD: installatie ==="
if ($proef) { Meld "(proefdraai: er wordt niets gekopieerd en niets in het register gezet)" }
Meld ""

# --- 1a. is de zip uitgepakt? ----------------------------------------------------------------
# Dubbelklikken in een zip laat Windows alleen dat ene bestand in een tijdelijke map uitpakken.
$tempPad = Normaliseer-Pad ([System.IO.Path]::GetTempPath())
$hier    = Normaliseer-Pad $PSScriptRoot
$uitZip  = ($hier.StartsWith($tempPad) -and ($hier -match '\.zip' -or $hier -match '\\temp\d+_'))
if ($uitZip -or -not (Test-Path -LiteralPath (Join-Path $bron "PackageContents.xml"))) {
    Stop-Installatie ("De installatie is gestart vanuit de zip, of de map $bundelNaam staat niet naast dit script.`n" +
        "Pak de zip eerst helemaal uit (rechtsklik op de zip > Alles uitpakken) en dubbelklik daarna`n" +
        "Installeer.bat in de uitgepakte map.")
}
$jarenInBundel = @(Get-ChildItem -LiteralPath (Join-Path $bron "Contents") -Directory |
    Where-Object { $_.Name -match '^\d{4}$' } | ForEach-Object { $_.Name })
Meld "Meegeleverd voor AutoCAD: $($jarenInBundel -join ', ')"

# --- 1b. AutoCAD moet dicht zijn -------------------------------------------------------------
# Een gesloten AutoCAD kan nog even als proces zichtbaar blijven (HasExited = waar) zolang een ander
# programma er een verwijzing naar vasthoudt; dat telt niet als draaiend. Niet te lezen = wel draaiend.
$acad = @(Get-Process -Name acad -ErrorAction SilentlyContinue |
    Where-Object { try { -not $_.HasExited } catch { $true } })
if ($acad.Count -gt 0) {
    if ($proef) {
        Meld "  PROEF: AutoCAD draait nu; de echte installatie stopt hier en vraagt AutoCAD te sluiten."
    } else {
        Stop-Installatie "AutoCAD draait nog. Sluit alle AutoCAD-vensters en start de installatie opnieuw."
    }
}

# --- 2. welke AutoCAD staat er op deze pc? ---------------------------------------------------
$gevonden = @()
foreach ($serie in $series.Keys) {
    $basis = "HKLM:\SOFTWARE\Autodesk\AutoCAD\$serie"
    if (-not (Test-Path $basis)) { continue }
    foreach ($prod in (Get-ChildItem $basis -ErrorAction SilentlyContinue)) {
        $naam = $null
        try { $naam = (Get-ItemProperty -LiteralPath $prod.PSPath -ErrorAction SilentlyContinue).ProductName } catch { }
        if ($naam) { $gevonden += "$naam ($serie)" }
    }
}
if ($gevonden.Count -gt 0) {
    Meld "Gevonden: $($gevonden -join '; ')"
} else {
    $lt = (Test-Path "HKLM:\SOFTWARE\Autodesk\AutoCAD LT") -or (Test-Path "HKCU:\Software\Autodesk\AutoCAD LT")
    if ($lt) {
        Stop-Installatie "Alleen AutoCAD LT gevonden. AutoCAD LT laadt geen .NET-plugins; VLEA werkt in AutoCAD 2025, 2026 of 2027 (ook Civil 3D en Map 3D)."
    }
    Stop-Installatie "Geen AutoCAD 2025, 2026 of 2027 gevonden op deze pc. VLEA werkt alleen in AutoCAD 2025, 2026 of 2027 (niet in LT)."
}

# --- akkoord ----------------------------------------------------------------------------------
Meld ""
Meld "Dit script:"
Meld "  - kopieert $bundelNaam naar $pluginMap"
Meld "  - zet voor elke AutoCAD-versie alleen de map met de DLL's ($doel\Contents\<jaar>)"
Meld "    in de lijst vertrouwde locaties van AutoCAD (TRUSTEDPATHS), niet de pluginmap zelf."
Meld "    Dat is een beveiligingsinstelling van AutoCAD. Verwijder.bat draait dit terug."
if (-not $proef -and -not $Ja) {
    $antwoord = Read-Host "Doorgaan? (J/N)"
    if ($antwoord -notmatch '^[JjYy]') { Meld "Afgebroken, er is niets gewijzigd."; exit 0 }
}

# --- 3. kopieren -------------------------------------------------------------------------------
Meld ""
if ($proef) {
    if (Test-Path -LiteralPath $doel) { Proef "de bestaande map vervangen: $doel" }
    Proef "kopieren: $bron -> $doel"
    Proef "Unblock-File uitvoeren op alle bestanden in $doel"
} else {
    New-Item -ItemType Directory -Force -Path $pluginMap | Out-Null
    if (Test-Path -LiteralPath $doel) { Remove-Item -LiteralPath $doel -Recurse -Force }
    Copy-Item -LiteralPath $bron -Destination $doel -Recurse -Force
    Get-ChildItem -LiteralPath $doel -Recurse -File | Unblock-File
    Meld "Geplaatst: $doel"
}

# --- 4. TRUSTEDPATHS, alleen in profielen van 2025, 2026 en 2027 ------------------------------
$profielen = 0
$bijgewerkt = 0
foreach ($serie in $series.Keys) {
    $jaar = $series[$serie]
    if ($jarenInBundel -notcontains $jaar) { continue }
    $vertrouwd = Join-Path $doel "Contents\$jaar"
    $root = "HKCU:\Software\Autodesk\AutoCAD\$serie"
    if (-not (Test-Path $root)) { continue }
    foreach ($prod in (Get-ChildItem $root -ErrorAction SilentlyContinue)) {
        $profielenKey = Join-Path $prod.PSPath "Profiles"
        if (-not (Test-Path -LiteralPath $profielenKey)) { continue }
        foreach ($profiel in (Get-ChildItem -LiteralPath $profielenKey -ErrorAction SilentlyContinue)) {
            $varKey = Join-Path $profiel.PSPath "Variables"
            if (-not (Test-Path -LiteralPath $varKey)) { continue }
            $profielen++
            $huidig = ""
            try { $huidig = [string](Get-ItemProperty -LiteralPath $varKey -Name "TRUSTEDPATHS" -ErrorAction Stop).TRUSTEDPATHS } catch { $huidig = "" }
            $delen = @($huidig -split ";" | Where-Object { $_ -and $_.Trim() })
            $alAanwezig = @($delen | Where-Object { (Normaliseer-Pad $_) -eq (Normaliseer-Pad $vertrouwd) }).Count -gt 0
            if ($alAanwezig) { continue }
            $nieuw = (@($delen) + $vertrouwd) -join ";"
            if ($proef) {
                Proef "in $serie / $($profiel.PSChildName) aan TRUSTEDPATHS toevoegen: $vertrouwd"
            } else {
                Set-ItemProperty -LiteralPath $varKey -Name "TRUSTEDPATHS" -Value $nieuw
            }
            $bijgewerkt++
        }
    }
}
Meld "AutoCAD-profielen gevonden: $profielen; TRUSTEDPATHS aangevuld in: $bijgewerkt."
if ($profielen -eq 0) {
    Meld ""
    Meld "LET OP: 0 profielen gevonden. AutoCAD maakt zijn profiel pas bij de eerste start."
    Meld "        Start AutoCAD een keer, sluit het weer en draai daarna deze installatie opnieuw."
    Meld "        Doe je dat niet, dan vraagt AutoCAD bij de start of de plugin geladen mag worden:"
    Meld "        kies dan 'Load' of 'Load Once'."
}

# --- 5. APPAUTOLOAD -----------------------------------------------------------------------------
# Standaard 14 (laden bij opstarten, bij een nieuwe tekening en als een plugin verschijnt).
# Staat hij op een waarde zonder bit 2, dan laadt AutoCAD bij het opstarten geen plugins.
$appAutoload = @()
foreach ($serie in $series.Keys) {
    $root = "HKCU:\Software\Autodesk\AutoCAD\$serie"
    if (-not (Test-Path $root)) { continue }
    foreach ($prod in (Get-ChildItem $root -ErrorAction SilentlyContinue)) {
        $kandidaten = @(Join-Path $prod.PSPath "Variables")
        $profielenKey = Join-Path $prod.PSPath "Profiles"
        if (Test-Path -LiteralPath $profielenKey) {
            foreach ($profiel in (Get-ChildItem -LiteralPath $profielenKey -ErrorAction SilentlyContinue)) {
                $kandidaten += (Join-Path $profiel.PSPath "Variables")
            }
        }
        foreach ($k in $kandidaten) {
            if (-not (Test-Path -LiteralPath $k)) { continue }
            $w = $null
            try { $w = (Get-ItemProperty -LiteralPath $k -Name "APPAUTOLOAD" -ErrorAction Stop).APPAUTOLOAD } catch { }
            if ($null -ne $w -and (([int]$w) -band 2) -eq 0) { $appAutoload += "$serie ($w)" }
        }
    }
}
if ($appAutoload.Count -gt 0) {
    Meld ""
    Meld "LET OP: APPAUTOLOAD staat zo dat AutoCAD bij het opstarten geen plugins laadt: $($appAutoload -join ', ')."
    Meld "        Typ in AutoCAD: APPAUTOLOAD en daarna 14."
} else {
    Meld "APPAUTOLOAD: in orde (standaard)."
}

Meld ""
if ($proef) {
    Meld "=== Proefdraai klaar: er is niets gewijzigd. ==="
} else {
    Meld "=== Klaar ==="
    Meld "Start AutoCAD. Het palet opent de eerste keer vanzelf; anders typ VKPALET."
    Meld "Vraagt AutoCAD of de plugin geladen mag worden, kies dan 'Load' of 'Load Once'."
    Meld "Verwijderen kan met Verwijder.bat uit dezelfde zip."
}
exit 0
