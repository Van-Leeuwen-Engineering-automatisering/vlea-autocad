# Verwijder.ps1 -- verwijdert "VLEA - kaarten voor AutoCAD" voor deze Windows-gebruiker.
#
# Start dit via Verwijder.bat. AutoCAD moet gesloten zijn.
#
# Wat het script doet, en ALLEEN dat:
#   1. haalt uit TRUSTEDPATHS (AutoCAD 2025, 2026 en 2027, elk profiel) precies de regels weg die
#      Installeer.ps1 heeft gezet: ...\ApplicationPlugins\VLEA-AutoCAD.bundle\Contents\<jaar>.
#      Paden worden exact vergeleken (hoofdletters en een afsluitende \ tellen niet mee); andere
#      regels, ook van andere plugins, blijven staan;
#   2. verwijdert de registraties die AutoCAD voor deze plugin heeft aangemaakt: alleen de vaste
#      namen "VLEA AutoCAD <jaar>", "... Palet" en "... Civil", en alleen als ze naar deze map wijzen;
#   3. verwijdert de map %APPDATA%\Autodesk\ApplicationPlugins\VLEA-AutoCAD.bundle.
#
# Instellingen en log in %LOCALAPPDATA%\VLEA-AutoCAD blijven staan (met -OokInstellingen weg).
#
# Proefdraai (schrijft niets):  powershell -NoProfile -ExecutionPolicy Bypass -File Verwijder.ps1 -Proefdraai
#
# ASCII-only: Windows PowerShell 5.1 leest dit bestand als cp1252.

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$Proefdraai,
    [switch]$Ja,
    [switch]$OokInstellingen
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$proef      = [bool]($Proefdraai -or $WhatIfPreference)
# Vangnet: in een proefdraai wordt elke schrijvende cmdlet sowieso alleen gesimuleerd.
if ($proef) { $WhatIfPreference = $true }
$bundelNaam = "VLEA-AutoCAD.bundle"
$series     = [ordered]@{ "R25.0" = "2025"; "R25.1" = "2026"; "R26.0" = "2027" }
$doel       = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\$bundelNaam"
$instellingen = Join-Path $env:LOCALAPPDATA "VLEA-AutoCAD"

function Meld([string]$t) { Write-Host $t }
function Proef([string]$t) { Write-Host "  PROEF: zou $t" }
function Normaliseer-Pad([string]$p) { return $p.Trim().TrimEnd('\').ToLowerInvariant() }

Meld "=== VLEA - kaarten voor AutoCAD: verwijderen ==="
if ($proef) { Meld "(proefdraai: er wordt niets verwijderd of gewijzigd)" }
Meld ""

# Een gesloten AutoCAD kan nog even als proces zichtbaar blijven (HasExited = waar) zolang een ander
# programma er een verwijzing naar vasthoudt; dat telt niet als draaiend. Niet te lezen = wel draaiend.
$acad = @(Get-Process -Name acad -ErrorAction SilentlyContinue |
    Where-Object { try { -not $_.HasExited } catch { $true } })
if ($acad.Count -gt 0) {
    if ($proef) {
        Meld "  PROEF: AutoCAD draait nu; het echte verwijderen stopt hier en vraagt AutoCAD te sluiten."
    } else {
        Meld "GESTOPT: AutoCAD draait nog. Sluit alle AutoCAD-vensters en start Verwijder.bat opnieuw."
        exit 1
    }
}

if (-not $proef -and -not $Ja) {
    $antwoord = Read-Host "VLEA verwijderen uit AutoCAD 2025, 2026 en 2027? (J/N)"
    if ($antwoord -notmatch '^[JjYy]') { Meld "Afgebroken, er is niets gewijzigd."; exit 0 }
}

# --- 1. TRUSTEDPATHS: exact onze regels eruit -----------------------------------------------------
$onzePaden = @()
foreach ($jaar in $series.Values) { $onzePaden += (Normaliseer-Pad (Join-Path $doel "Contents\$jaar")) }

$weg = 0
foreach ($serie in $series.Keys) {
    $root = "HKCU:\Software\Autodesk\AutoCAD\$serie"
    if (-not (Test-Path $root)) { continue }
    foreach ($prod in (Get-ChildItem $root -ErrorAction SilentlyContinue)) {
        $profielenKey = Join-Path $prod.PSPath "Profiles"
        if (-not (Test-Path -LiteralPath $profielenKey)) { continue }
        foreach ($profiel in (Get-ChildItem -LiteralPath $profielenKey -ErrorAction SilentlyContinue)) {
            $varKey = Join-Path $profiel.PSPath "Variables"
            if (-not (Test-Path -LiteralPath $varKey)) { continue }
            $huidig = ""
            try { $huidig = [string](Get-ItemProperty -LiteralPath $varKey -Name "TRUSTEDPATHS" -ErrorAction Stop).TRUSTEDPATHS } catch { continue }
            $delen = @($huidig -split ";" | Where-Object { $_ -and $_.Trim() })
            $blijft = @($delen | Where-Object { $onzePaden -notcontains (Normaliseer-Pad $_) })
            $aantal = $delen.Count - $blijft.Count
            if ($aantal -eq 0) { continue }
            if ($proef) {
                Proef "in $serie / $($profiel.PSChildName) $aantal regel(s) uit TRUSTEDPATHS halen"
            } else {
                Set-ItemProperty -LiteralPath $varKey -Name "TRUSTEDPATHS" -Value ($blijft -join ";")
            }
            $weg += $aantal
        }
    }
}
Meld "TRUSTEDPATHS: $weg regel(s) van VLEA verwijderd."

# --- 2. registraties van de autoloader ------------------------------------------------------------
$appNamen = @()
foreach ($jaar in $series.Values) {
    $appNamen += "VLEA AutoCAD $jaar", "VLEA AutoCAD $jaar Palet", "VLEA AutoCAD $jaar Civil"
}
$prefix = (Normaliseer-Pad $doel) + "\"
$registraties = 0
foreach ($serie in $series.Keys) {
    $root = "HKCU:\Software\Autodesk\AutoCAD\$serie"
    if (-not (Test-Path $root)) { continue }
    foreach ($prod in (Get-ChildItem $root -ErrorAction SilentlyContinue)) {
        $apps = Join-Path $prod.PSPath "Applications"
        if (-not (Test-Path -LiteralPath $apps)) { continue }
        foreach ($app in (Get-ChildItem -LiteralPath $apps -ErrorAction SilentlyContinue)) {
            if ($appNamen -notcontains $app.PSChildName) { continue }
            $loader = ""
            try { $loader = [string](Get-ItemProperty -LiteralPath $app.PSPath -Name "LOADER" -ErrorAction Stop).LOADER } catch { continue }
            if (-not (Normaliseer-Pad $loader).StartsWith($prefix)) { continue }
            if ($proef) {
                Proef "registratie verwijderen: $serie \ $($app.PSChildName)"
            } else {
                Remove-Item -LiteralPath $app.PSPath -Recurse -Force
            }
            $registraties++
        }
    }
}
Meld "Registraties van VLEA verwijderd: $registraties."

# --- 3. de map ----------------------------------------------------------------------------------
if (Test-Path -LiteralPath $doel) {
    if ($proef) { Proef "de map verwijderen: $doel" }
    else { Remove-Item -LiteralPath $doel -Recurse -Force; Meld "Map verwijderd: $doel" }
} else {
    Meld "De map $doel bestaat niet (al verwijderd)."
}

if ($OokInstellingen -and (Test-Path -LiteralPath $instellingen)) {
    if ($proef) { Proef "instellingen en log verwijderen: $instellingen" }
    else { Remove-Item -LiteralPath $instellingen -Recurse -Force; Meld "Instellingen verwijderd: $instellingen" }
} elseif (Test-Path -LiteralPath $instellingen) {
    Meld "Instellingen en log blijven staan in $instellingen (verwijder met -OokInstellingen)."
}

Meld ""
if ($proef) { Meld "=== Proefdraai klaar: er is niets gewijzigd. ===" } else { Meld "=== Klaar. VLEA is verwijderd. ===" }
exit 0
